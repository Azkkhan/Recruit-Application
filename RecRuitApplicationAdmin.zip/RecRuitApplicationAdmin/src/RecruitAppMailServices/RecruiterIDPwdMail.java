package RecruitAppMailServices;

import java.util.Properties;

import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.sql.rowset.spi.TransactionalWriter;

import com.sun.mail.handlers.message_rfc822;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessageContext;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;

public class RecruiterIDPwdMail {

	public static String sendMail(String toEMail,String password) {
		String senderID="mazeemxyz@gmail.com";
		String pwd="kaisar555";
		String toMailID=toEMail;
		Properties props=new Properties();
		props.put("mail.smtp.auth","true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host","smtp.gmail.com");
		props.put("mail.smtp.port", "587");
		
		Session session=Session.getDefaultInstance(props,new Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(senderID, pwd);
			}
		});
		
		try {
			Message msg=new MimeMessage(session);
			msg.setFrom(new InternetAddress(senderID));
			msg.setRecipient(Message.RecipientType.TO,new InternetAddress(toMailID));
			msg.setSubject("Hello this is your LoginID And Password");
			msg.setText("User ID :"+toEMail +"\n"+"Password :"+password);
			Transport.send(msg);
			
			return "Submitted Successful Check Your Email for UserID and Password";
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return "Mail not send Yet";
	}
	public static void main(String[] args) {
		System.out.println(sendMail("azeemkaisarkhan@gmail.com","pwd"));
	}
}
