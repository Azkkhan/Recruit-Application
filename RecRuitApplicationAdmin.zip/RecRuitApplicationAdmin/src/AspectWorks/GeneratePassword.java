package AspectWorks;

import java.util.Random;

public class GeneratePassword {

	public static String getPassword(String name,long number) {
		String values=name+number;
		Random rndm=new Random();
		int length=8;
		char[] password=new char[length];
		for(int i=0;i<length;i++) {
			password[i]=values.charAt(rndm.nextInt(values.length()));
		}
		String pwd=new String(password);
		return pwd;
	}
}
