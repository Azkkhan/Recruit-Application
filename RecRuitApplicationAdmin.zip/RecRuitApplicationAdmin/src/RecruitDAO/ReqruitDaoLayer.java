package RecruitDAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ReqruitDaoLayer {
	static Connection con;
	static {
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("#1");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/companies","root","systemroot");
			System.out.println("#2");
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		
	}
	public static Connection getConnection() {
		return con;
	}

}
