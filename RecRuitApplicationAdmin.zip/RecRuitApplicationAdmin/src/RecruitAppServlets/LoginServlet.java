package RecruitAppServlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.lang.ProcessBuilder.Redirect;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import RecruitDAO.ReqruitDaoLayer;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		PrintWriter out=res.getWriter();
		
		String uname=req.getParameter("username");
		String pwd=req.getParameter("pass");
		Connection con=ReqruitDaoLayer.getConnection();
		RequestDispatcher rd=null;
		HttpSession session=req.getSession();
		
		try {
			PreparedStatement ps=con.prepareStatement("select email,pwd from RecruitApp where email=? and pwd=? ");
			
			ps.setString(1, uname);
			ps.setString(2, pwd);
			
			
			ResultSet rs=ps.executeQuery();
			
			if(rs==null) {
					
				throw new SQLException();
			}
			else {
				session=req.getSession();
				session.setAttribute("name",uname);
				while(rs.next()) {
					
					rd=req.getRequestDispatcher("AfterLogin/postjob.jsp");
					rd.forward(req, res);
					//return;
				}	
			}
			throw new SQLException();
		} catch (SQLException e) {
			
			
			
			rd=req.getRequestDispatcher("login.html");
			rd.include(req, res);
			
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
		
	}

}

