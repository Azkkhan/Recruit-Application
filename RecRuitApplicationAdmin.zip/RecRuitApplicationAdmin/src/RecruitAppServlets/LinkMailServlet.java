package RecruitAppServlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.mail.MessagingException;

import AspectWorks.GeneratePassword;
import RecruitAppMailServices.RecruiterIDPwdMail;
import RecruitDAO.ReqruitDaoLayer;


@WebServlet("/linkMail")
public class LinkMailServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	PrintWriter out=response.getWriter();
    	String name=request.getParameter("CName");
    	String email=request.getParameter("CEmail");
    	long number=Long.parseLong(request.getParameter("CNumber"));
    	String location=request.getParameter("CLocation");
    	//Generate password 
    	String password =GeneratePassword.getPassword(name, number);
    	
    	//Get Connection 
    	Connection con=ReqruitDaoLayer.getConnection();
    	try {
			PreparedStatement ps=con.prepareStatement("insert into RecruitApp(ename,email,pwd,mobile,location) values(?,?,?,?,?)");
			ps.setString(1, name);
			ps.setString(2, email);
			ps.setString(3, password);
			ps.setLong(4, number);
			ps.setString(5, location);
			int update=ps.executeUpdate();
			String docType="<!doctype html public \"-//w3c//dtd html 4.0 " +
	         "transitional//en\">\n";
			if(update==1) {
				out.println(RecruiterIDPwdMail.sendMail(email, password));
				RequestDispatcher rd=request.getRequestDispatcher("login.html");
				rd.forward(request, response);
				
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		doGet(request, response);
	}

}
